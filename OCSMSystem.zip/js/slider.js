var sliderOptions =
        {
            sliderId: "slider",
            effect: "17,13,1",
            effectRandom: true,
            pauseTime: 2800,
            transitionTime: 1200,
            slices: 14,
            boxes: 8,
            hoverPause: 1,
            autoAdvance: true,
            captionOpacity: 0.4,
            captionEffect: "fade",
            thumbnailsWrapperId: "thumbs",
            m: false,
            license: "mylicense"
        };