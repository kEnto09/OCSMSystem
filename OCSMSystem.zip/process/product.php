

<?php

error_reporting(E_ALL);
ini_set('display_errors', '1');
?>
<?php

if (isset($_GET['productid'])) {

    include "../storescripts/dbconnect.php";
	$productid = preg_replace('#[^0-9]#i', '', $_GET['productid']);

	$sql = mysql_query("SELECT * FROM products WHERE productid='$productid' LIMIT 1");
	$productCount = mysql_num_rows($sql);
    if ($productCount > 0) {
		while($row = mysql_fetch_array($sql)){
			 $name = $row["name"];
			 $description= $row["description"];
       $price = $row["price"];
			 $category = $row["category"];
			 $dateadded = strftime("%b %d, %Y", strtotime($row["dateadded"]));
         }

	} else {
		echo "That item does not exist.";
	    exit();
	}

} else {
	echo "Data to render this page is missing.";
	exit();
}
mysql_close();
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

<title><?php echo $name; ?></title>
<link href="../css/bootstrap.min.css" rel="stylesheet">

<!-- Custom CSS -->
<link href="../css/freelancer.css" rel="stylesheet">
<link href="../css/mediaquery.css" rel="stylesheet">

<!-- Custom Fonts -->
<link href="../js/jquery.easing.min.js" rel="stylesheet" type="text/css">
<link href="../js/jsfontaccurate.js" rel="stylesheet" type="text/css">
<link href="../font-awesome-4.1.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="../css/font.css" rel="stylesheet" type="text/css">
<link href="../css/fontfamily.css" rel="stylesheet" type="text/css">

<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->

</head>

</head>
<body>

  <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
          <!-- Brand and toggle get grouped for better mobile display -->
          <div class="navbar-header page-scroll">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                  <span class="sr-only">Toggle navigation</span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
              </button>
              <a class="navbar-brand" href="#page-top">Gretz Paul Food Corporation</a>
          </div>

          <!-- Collect the nav links, forms, and other content for toggling -->
          <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
              <ul class="nav navbar-nav navbar-right">
                <li>
                  <a href="cart.php"><img src="../glyphicons_free/glyphicons/png/glyphicons-203-shopping-cart.png"></a>
                </li>
              </ul>
          </div>
          <!-- /.navbar-collapse -->
      </div>
      <!-- /.container-fluid -->
  </nav>

  <section id="breads">
      <div class="container">
          <div class="row">
          </br>
          </br>
          </br>
        <div class="col-lg-12 text-center">


<div align="center" id="container">
  <table align="center" width="100%" border="0" cellspacing="0" cellpadding="15">
  <tr>
    <td width="19%" valign="top"><img src="../inventory_images/<?php echo $productid; ?>.jpg" width="142" height="188" alt="<?php echo $name; ?>" /><br />

    <td width="81%" valign="top"><h3><?php echo $name; ?></h3>
      <p><?php echo "P".$price; ?><br />
        <br />
        <?php echo "$category"; ?> <br />
<br />
        <?php echo $description; ?>
<br />
<p>
<form id="form1" align="center" name="form1" method="post" action="cart.php">
        <input type="hidden" name="productid" id="productid" value="<?php echo $productid; ?>" />
        <input type="submit" name="button" class="btn-default" id="button" value="Add to Cart" />
      </form>
  </div>
</p>
        </p>

      </td>
    </tr>
</table>


</div>
</div>
</div>
</section>

<footer class="text-center">
       <div class="footer-above">
           <div class="container">
               <div class="row">
                   <div class="footer-col col-md-4">
                       <h3>Location</h3>
                       <p>Brgy. Kudanding, Isulan,<br>Sultan Kudarat</p>
                   </div>
                   <div class="footer-col col-md-4">
                       <h3>Around the Web</h3>
                       <ul class="list-inline">
                           <li>
                               <a href="#" class="btn-social btn-outline"><i class="fa fa-fw fa-facebook"></i></a>
                           </li>
                           <li>
                               <a href="#" class="btn-social btn-outline"><i class="fa fa-fw fa-google-plus"></i></a>
                           </li>
                           <li>
                               <a href="#" class="btn-social btn-outline"><i class="fa fa-fw fa-twitter"></i></a>
                           </li>
                           <li>
                               <a href="#" class="btn-social btn-outline"><i class="fa fa-fw fa-linkedin"></i></a>
                           </li>
                           <li>
                               <a href="#" class="btn-social btn-outline"><i class="fa fa-fw fa-dribbble"></i></a>
                           </li>
                       </ul>
                   </div>
                   <div class="footer-col col-md-4">
                       <h3>About the Programming Language</h3>
                       <p>KJM Media is appreciating the open source webtool <a href="http://getbootstrap.com">Bootstrap 3</a>.</p>
                   </div>
               </div>
           </div>
       </div>
       <div class="footer-below">
           <div class="container">
               <div class="row">
                   <div class="col-lg-12">
                       Copyright &copy; KJM Media 2014
                   </div>
               </div>
           </div>
       </div>
   </footer>

</body>
</html>
