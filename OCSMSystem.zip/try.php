<?php
  include ('storescripts/dbconnect.php');

$stock = $sql = mysql_query("SELECT * FROM product");

  if ($stock >= 5) {
   
    echo "<span>Low Stock</span>";
  }
?>
