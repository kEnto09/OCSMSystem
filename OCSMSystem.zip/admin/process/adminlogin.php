<?php
session_start();
if (isset($_SESSION["manager"])) {
    header("location: ../index.php");
    exit();
}
?>
<?php

if (isset($_POST["username"]) && isset($_POST["password"])) {

	  $manager = preg_replace('#[^A-Za-z0-9]#i', '', $_POST["username"]);
    $password = preg_replace('#[^A-Za-z0-9]#i', '', $_POST["password"]);
    include "../storescripts/dbconnect.php";
    $sql = mysql_query("SELECT id FROM admin WHERE username='$manager' AND password='$password' LIMIT 1");
    $existCount = mysql_num_rows($sql);
    if ($existCount == 1) {
	     while($row = mysql_fetch_array($sql)){
             $id = $row["id"];
		 }
		 $_SESSION["id"] = $id;
		 $_SESSION["manager"] = $manager;
		 $_SESSION["password"] = $password;
		 header("location: ../index.php");
         exit();
    } else {
		echo 'That information is incorrect, try again <a href="../index.php"><input type="submit" name="button" id="button" value="Click Here" /></a>';
		exit();
	}
}
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Admin Log In </title>

<link href="../../css/bootstrap.min.css" rel="stylesheet">

<!-- Custom CSS -->
<link href="../../css/freelancer.css" rel="stylesheet">
<link href="../../css/mediaquery.css" rel="stylesheet">

<!-- Custom Fonts -->
<link href="../../js/jquery.easing.min.js" rel="stylesheet" type="text/css">
<link href="../../js/jsfontaccurate.js" rel="stylesheet" type="text/css">
<link href="../../font-awesome-4.1.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="../../css/font.css" rel="stylesheet" type="text/css">
<link href="../../css/fontfamily.css" rel="stylesheet" type="text/css">

<link rel="stylesheet" href="css/freelancer.css" type="text/css" media="screen" />
</head>

<body>
<div align="center" id="mainWrapper">
  <div id="container"><br />
    <div class="row">
      <div class="col-lg-8 col-lg-offset-2">
      <h2>Log in and Manage</h2>
      <form id="form1" name="form1" method="post" action="adminlogin.php">
        User Name:<br />
          <input name="username" type="text" id="username" size="40" />
        <br /><br />
        Password:<br />
       <input name="password" type="password" id="password" size="40" />
       <br />
       <br />
       <br />

         <input type="submit" name="button" class="btn btn-default btn-xs" id="button" value="Log In" />

      </form>
      <p>&nbsp; </p>
    </div>
    <br />
  <br />
  <br />
  </div>
</div>

  <script src="../../js/freelancer.js"></script>

    <footer class="text-center">
           <div class="footer-above">
               <div class="container">
                   <div class="row">
                       <div class="footer-col col-md-4">
                           <h3>Location</h3>
                           <p>Brgy. Kudanding, Isulan,<br>Sultan Kudarat</p>
                       </div>
                       <div class="footer-col col-md-4">
                           <h3>Around the Web</h3>
                           <ul class="list-inline">
                               <li>
                                   <a href="#" class="btn-social btn-outline"><i class="fa fa-fw fa-facebook"></i></a>
                               </li>
                               <li>
                                   <a href="#" class="btn-social btn-outline"><i class="fa fa-fw fa-google-plus"></i></a>
                               </li>
                               <li>
                                   <a href="#" class="btn-social btn-outline"><i class="fa fa-fw fa-twitter"></i></a>
                               </li>
                               <li>
                                   <a href="#" class="btn-social btn-outline"><i class="fa fa-fw fa-linkedin"></i></a>
                               </li>
                               <li>
                                   <a href="#" class="btn-social btn-outline"><i class="fa fa-fw fa-dribbble"></i></a>
                               </li>
                           </ul>
                       </div>
                       <div class="footer-col col-md-4">
                           <h3>About the Programming Language</h3>
                           <p>KJM appreciating the open source webtool <a href="http://getbootstrap.com">Bootstrap 3</a>.</p>
                       </div>
                   </div>
               </div>
           </div>
           <div class="footer-below">
               <div class="container">
                   <div class="row">
                       <div class="col-lg-12">
                           Copyright &copy; KJM 2016
                       </div>
                   </div>
               </div>
           </div>
       </footer>


    </body>
</html>
