<?php
session_start();
if (!isset($_SESSION["bmanager"])) {
    header("location: bmlogin.php");
    exit();
}
$bmid = preg_replace('#[^0-9]#i', '', $_SESSION["id"]);
$bmanager = preg_replace('#[^A-Za-z0-9]#i', '', $_SESSION["bmanager"]);
$password = preg_replace('#[^A-Za-z0-9]#i', '', $_SESSION["password"]);///
include "../../storescripts/dbconnect.php";
$sql = mysql_query("SELECT * FROM bm1 WHERE id='$bmid' AND username='$bmanager' AND password='$password' LIMIT 1");
$existCount = mysql_num_rows($sql);
if ($existCount == 0) {
	 echo "Your login session data is not on record in the database.";
     exit();
}
?>
<?php
include ('../../../storescripts/dbconnect.php');
$cartOutput = "";
$cartTotal = "";
$pp_checkout_btn = '';
$product_id_array = '';
$quantity = '';
$cart_array = '';
if (!isset($_SESSION["cart_array"]) || count($_SESSION["cart_array"]) < 1) {
    $cartOutput = "<h2 align='center'>Your shopping cart is empty</h2>";
} else {

  $i = 0;
    foreach ($_SESSION["cart_array"] as $each_item) {
    $productid = $each_item['productid'];
    $sql = mysql_query("SELECT * FROM product WHERE productid='$productid' LIMIT 1");
    while ($row = mysql_fetch_array($sql)) {
      $name = $row["name"];
      $price = $row["price"];
      $category = $row["category"];
      $description = $row["description"];
    }

    $pricetotal = $price * $each_item['quantity'];
    $cartTotal = $pricetotal + $cartTotal;


    $quantity = $each_item['quantity'] + $quantity;

    $x = $i + 1;
    $pp_checkout_btn .= '<input type="hidden" name="item_name_' . $x . '" value="' . $name . '">
        <input type="hidden" name="amount_' . $x . '" value="' . $price . '">
        <input type="hidden" name="quantity_' . $x . '" value="' . $each_item['quantity'] . '">  ';

    $product_id_array .= "$productid-".$each_item['quantity'].",";

    $cartOutput .= "<tr>";
    $cartOutput .= '<td>' . $name . '<br /><img src="../../branchmanagers/bm1/productlist/' . $productid . '.jpg" alt="' . $name. '" width="70" height="52" border="1" /></td>';

    $cartOutput .= '<td>Php' . $price . '.00</td>';
    $cartOutput .= '<td><form action="cart.php" method="post">
    <input name="quantity" type="text" value="' . $each_item['quantity'] . '" size="1" maxlength="2" /> &nbsp;
    <input name="adjustBtn' . $productid . '" type="submit" class="btn-default" value="CHANGE" />
    <input name="item_to_adjust" type="hidden" value="' . $productid . '" />
    </form></td>';

    $cartOutput .= '<td>PHP &nbsp;' . $pricetotal . '.00</td>';
    $cartOutput .= '<td><form action="cart.php" method="post"><input name="deleteBtn' . $productid . '" type="submit" value="X" /><input name="index_to_remove" type="hidden" value="' . $i . '" /></form></td>';
    $cartOutput .= '</tr>';
    $i++;
    }
  $cartTotal = "<div style='font-size:18px; margin-top:12px;' align='right'>Cart Total :Php ".$cartTotal." .00</div>";

  $pp_checkout_btn .= '<input type="hidden" name="custom" value="' . $product_id_array . '">
  <input type="hidden" name="notify_url" value="/storescripts/my_ipn.php">
  <input type="hidden" name="return" value="https://www.yoursite.com/checkout_complete.php">
  <input type="hidden" name="rm" value="2">
  <input type="hidden" name="cbt" value="Return to The Store">
  <input type="hidden" name="cancel_return" value="https://www.yoursite.com/paypal_cancel.php">
  <input type="hidden" name="lc" value="Php">
  <input type="hidden" name="currency_code" value="">
  <input type="button" name="submit" class="btn btn-default" value="Purchase">
  </form>';
}
?>


<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Branch Manager</title>
    <link href="../../css/js-image-slider.css" rel="stylesheet" type="text/css" />
    <script src="../../js/js-image-slider.js" type="text/javascript"></script>

    <!-- Bootstrap Core CSS - Uses Bootswatch Flatly Theme: http://bootswatch.com/flatly/ -->
    <link href="../../css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../../css/freelancer.css" rel="stylesheet">
    <link href="../../css/mediaquery.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../../js/jquery.easing.min.js" rel="stylesheet" type="text/css">
    <link href="../../js/jsfontaccurate.js" rel="stylesheet" type="text/css">
    <link href="../../font-awesome-4.1.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="../../css/font.css" rel="stylesheet" type="text/css">
    <link href="../../css/fontfamily.css" rel="stylesheet" type="text/css">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body id="page-top" class="index">

    <!-- Navigation -->
    <nav class="navbar navbar-default navbar-fixed-top">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#page-top">Isulan Gret'z Paul</a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li class="hidden">
                        <a href="#page-top"></a>
                    </li>

                    <li class="page-scroll">
                         <a href="branch1.php">add item</a>
                     </li>
                       <li>
                         <a href="report.php">View Reports</a>
                       </li>
                       <li>
     <form class="navbar-form navbar-left" method="POST" action="search.php">
       <div class="form-group">
         <input type="text" name="search" id="search" class="form-control" placeholder="Search products..">
       </div>
       <button type="submit" class="btn btn-default">Search</button>
     </form>
                       </li>
                         <li>
                             <a href="bm1logout.php"><span class="glyphicon glyphicon-off" aria-hidden="true"></span></a>
                           </li>

                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>
    <br/><br/><br/><br/><br/>
    <section id="manage">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2>manage store items</h2>
                    <hr class="star-primary">
                </div>
            </div>
          <div class="row">
            <div align="center" id="mainWrapper">
              <div id="pageContent">
                <div align="center" style="margin-right:32px;">
                  <div id="pageContent">
                    <?php
                    error_reporting(E_ALL);
                    ini_set('display_errors', '1');
                    ?>
                    <?php
                    include "../../../storescripts/dbconnect.php";
                    $dynamicListBread = "";
                    $dynamicListPastries = "";
                    $dynamicListCakes = "";
                    $dynamicListCakes2 = "";
                    $sql = mysql_query("SELECT * FROM product ORDER BY date_added DESC LIMIT 12");
                    $productCount = mysql_num_rows($sql);
                    if ($productCount > 0) {
                      while($row = mysql_fetch_array($sql)){
                          $productid = $row["productid"];
                           $name = $row["name"];
                           $description = $row["description"];
                           $category = $row["category"];
                           $price = $row["price"];
                           $date_added = strftime("%b %d, %Y", strtotime($row["date_added"]));

                           if ($category=='Breads')
                           {

                             $dynamicListBread .= '<table border="0" cellspacing="0" cellpadding="">

                                <img style="border:#666 1px solid;" src="productlist/' . $productid . '.jpg" alt="' . $name . '" width="280" height="150" border="1" /></th>
                                <div align="center">' .$name. ' </div>
                                  <div align="center">Php &nbsp; ' . $price . '.00</div>
                                <div align="center"><a href="prodedit.php?productid=' . $productid . '"><button type="button" class="btn-default">UPDATE</button></a></th>
                                  </div>
                                  </table><br/><br/>';
                              }
                            if ($category=='Pastries')
                             {

                             $dynamicListPastries .= '<table border="0" cellspacing="0" cellpadding="">

                                <img style="border:#666 1px solid;" src="productlist/' . $productid . '.jpg" alt="' . $name . '" width="280" height="150" border="1" /></th>
                                <div align="center">' .$name. ' </div>
                                  <div align="center">Php &nbsp; ' . $price . '.00</div>
                                <div align="center"><a href="prodedit.php?productid=' . $productid . '"><button type="button" class="btn-default">UPDATE</button></a></th>
                                  </div>
                                  </table><br/><br/>';
                              }
                              if ($category=='Cakes')
                              {

                              $dynamicListCakes .= '<table border="0" cellspacing="0" cellpadding="">

                                 <img style="border:#666 1px solid;" src="productlist/' . $productid . '.jpg" alt="' . $name . '" width="280" height="150" border="1" /></th>
                                 <div align="center">' .$name. ' </div>
                                   <div align="center">Php &nbsp; ' . $price . '.00</div>
                                 <div align="center"><a href="prodedit.php?productid=' . $productid . '"><button type="button" class="btn-default">UPDATE</button></a></th>
                                   </div>
                                   </table><br/><br/>';
                               }
                             if ($category=='Cakes2')
                              {

                                $dynamicListCakes2 .= '<table border="0" cellspacing="0" cellpadding="">

                                   <img style="border:#666 1px solid;" src="productlist/' . $productid . '.jpg" alt="' . $name . '" width="280" height="150" border="1" /></th>
                                   <div align="center">' .$name. ' </div>
                                     <div align="center">Php &nbsp; ' . $price . '.00</div>
                                   <div align="center"><a href="prodedit.php?productid=' . $productid . '"><button type="button" class="btn-default">UPDATE</button></a></th>
                                     </div>
                                     </table><br/><br/>';
                               }
                         }
                     } else {
                       $dynamicList = "We have no products listed in our store yet";
                     }
                     mysql_close();
                     ?>
                    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
                    <div align="center" id="mainWrapper">

                      <div id="pageContent">
                      <table width="100%" border="0" cellspacing="10" cellpadding="10">
                      <tr>
                        <td width="25%" valign="top"><h3>Breads</h3>
                          <p><?php echo $dynamicListBread; ?><br />
                            </p>
                          <p><br />
                          </p></td>
                           <th width="25%" valign="top"><h3>Pastries</h3>
                          <p><?php echo $dynamicListPastries; ?><br />
                            </p>
                          <p><br />
                          </p></td>
                          <td width="25%" valign="top"><h3>Cakes</h3>
                            <p><?php echo $dynamicListCakes; ?><br />
                              </p>
                            <p><br />
                            </p></td>
                             <th width="25%" valign="top"><h3>Other Cake</h3>
                            <p><?php echo $dynamicListCakes2; ?><br />
                              </p>
                            <p><br />
                            </p></td>
                      </tr>
                    </table>
                 </div>
               </div>
             </div>
           </div>
         </div>

</section>

<footer class="text-center">
       <div class="footer-above">
           <div class="container">
               <div class="row">
                   <div class="footer-col col-md-4">
                       <h3>Location</h3>
                       <p>Brgy. Kudanding, Isulan</br>Sultan Kudarat</p>
                   </div>
                   <div class="footer-col col-md-4">
                       <h3>Around the Web</h3>
                       <ul class="list-inline">
                           <li>
                               <a href="facebook.com" class="btn-social btn-outline"><i class="fa fa-fw fa-facebook"></i></a>
                           </li>
                           <li>
                               <a href="#" class="btn-social btn-outline"><i class="fa fa-fw fa-google-plus"></i></a>
                           </li>
                           <li>
                               <a href="#" class="btn-social btn-outline"><i class="fa fa-fw fa-twitter"></i></a>
                           </li>
                           <li>
                               <a href="#" class="btn-social btn-outline"><i class="fa fa-fw fa-linkedin"></i></a>
                           </li>
                           <li>
                               <a href="#" class="btn-social btn-outline"><i class="fa fa-fw fa-dribbble"></i></a>
                           </li>
                       </ul>
                   </div>
                   <div class="footer-col col-md-4">
                       <h3>About the Programming Language</h3>
                       <p>KeMitch is appreciating the open source webtool <a href="http://getbootstrap.com">Bootstrap 3</a>.</p>
                   </div>
               </div>
           </div>
       </div>
       <div class="footer-below">
           <div class="container">
               <div class="row">
                   <div class="col-lg-12">
                       Copyright &copy; KeMitch 2016
                   </div>
               </div>
           </div>
       </div>
   </footer>

       <!-- jQuery Version 1.11.0 -->
       <script src="../../../js/jquery-1.11.0.js"></script>

       <!-- Bootstrap Core JavaScript -->
       <script src="../../../js/bootstrap.min.js"></script>

       <!-- Plugin JavaScript -->
       <script src="../../../js/jquery.easing.min.js"></script>
       <script src="../../../js/classie.js"></script>
       <script src="../../../js/cbpAnimatedHeader.js"></script>

       <!-- Contact Form JavaScript -->
       <script src="../../../js/jqBootstrapValidation.js"></script>

       <!-- Custom Theme JavaScript -->
       <script src="../../../js/freelancer.js"></script>
    </body>
    </html>
