<?php
session_start();
if (!isset($_SESSION["bmanager"])) {
    header("location: bmlogin.php");
    exit();
}
$bmid = preg_replace('#[^0-9]#i', '', $_SESSION["id"]);
$bmanager = preg_replace('#[^A-Za-z0-9]#i', '', $_SESSION["bmanager"]);
$password = preg_replace('#[^A-Za-z0-9]#i', '', $_SESSION["password"]);///
include "../../../storescripts/dbconnect.php";
$sql = mysql_query("SELECT * FROM bm1 WHERE id='$bmid' AND username='$bmanager' AND password='$password' LIMIT 1");
$existCount = mysql_num_rows($sql);
if ($existCount == 0) {
	 echo "Your login session data is not on record in the database.";
     exit();
}
?>

<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');
?>
<?php

if (isset($_GET['deleteid'])) {
  echo 'Do you really want to delete product with ID of ' . $_GET['deleteid'] . '? <a href="branch1.php?yesdelete=' . $_GET['deleteid'] . '">Yes</a> | <a href="branch1.php">No</a>';
  exit();
}
if (isset($_GET['yesdelete'])) {

  $id_to_delete = $_GET['yesdelete'];
  $sql = mysql_query("DELETE FROM products WHERE id='$id_to_delete' LIMIT 1") or die (mysql_error());

    $pictodelete = ("productlist/$id_to_delete.jpg");
    if (file_exists($pictodelete)) {
              unlink($pictodelete);
    }
  header("location: branch1.php");
    exit();
}
?>
<?php

if (isset($_POST['name'])) {
  $name = mysql_real_escape_string($_POST['name']);
  $description = mysql_real_escape_string($_POST['description']);
  $stock = mysql_real_escape_string($_POST['stock']);
  $category = mysql_real_escape_string($_POST['category']);
  $price = mysql_real_escape_string($_POST['price']);
  $sql = mysql_query("SELECT productid FROM product WHERE name='$name' LIMIT 1");
  $productMatch = mysql_num_rows($sql);
    if ($productMatch > 0) {
    echo 'Sorry you tried to place a duplicate "Product Name" into the system, <a href="branch1.php">click here</a>';
    exit();
  }

  $sql = mysql_query("INSERT INTO product (name, description, stock, category ,price ,date_added)
        VALUES('$name','$description','$stock','$category','$price',now())") or die (mysql_error());
     $productid = mysql_insert_id();
  $newname = "$productid.jpg";
  move_uploaded_file( $_FILES['fileField']['tmp_name'], "productlist/$newname");
  header("location: branch1.php");
    exit();
}

?>



<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Branch Manager</title>
    <link href="../../../css/js-image-slider.css" rel="stylesheet" type="text/css" />
    <script src="../../../js/js-image-slider.js" type="text/javascript"></script>
    <!-- Bootstrap Core CSS - Uses Bootswatch Flatly Theme: http://bootswatch.com/flatly/ -->
    <link href="../../../css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../../../css/freelancer.css" rel="stylesheet">
    <link href="../../../css/mediaquery.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../../../js/jquery.easing.min.js" rel="stylesheet" type="text/css">
    <link href="../../../js/jsfontaccurate.js" rel="stylesheet" type="text/css">
    <link href="../../../font-awesome-4.1.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="../../../css/font.css" rel="stylesheet" type="text/css">
    <link href="../../../css/fontfamily.css" rel="stylesheet" type="text/css">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body id="page-top" class="index">

    <!-- Navigation -->
    <nav class="navbar navbar-default navbar-fixed-top">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#page-top">Gretz Paul Food Corporation</a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li class="hidden">
                        <a href="#page-top"></a>
                    </li>

                    <li>
                         <a href="branch1.php">add item</a>
                     </li>
                     <li>
                         <a href="prodlist.php">View Products</a>
                       </li>
                       <li>
                         <a href="report.php">View Reports</a>
                       </li>
                     <li>
                            <a href="bm1logout.php"><span class="glyphicon glyphicon-off" aria-hidden="true"></span></a>
                          </li>

                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>
<br/><br/><br/>

    <section id="manage">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2>manage store items</h2>
                    <hr class="star-primary">
                </div>
            </div>
          <div class="row">
            <div align="center" id="mainWrapper">
              <div id="pageContent">
                <div align="center" style="margin-right:1px;">
                  <div id="pageContent">
                    <a name="inventoryForm" id="inventoryForm" novalidate></a>

                    <form action="branch1.php" enctype="multipart/form-data" name="myForm" id="myform" method="post">
                      <div width="40%">
                        <tr><h3>Add Items In Your Store</h3><br/><br/>
                          <div class="row">
                            <td align="right"></td>
                            <td><label>
                              <input name="name" class="form-control" type="text" id="name" size="42" placeholder="Name" />
                            </label></td>
                          </div>
                        </tr>
                        <tr></br>
                          <div class="row">
                          <th align="right"></th>
                          <th><label>
                            <input name="price" class="form-control" type="text" id="price" size="10" placeholder="Price" />
                          </label></th>
                        </tr>
                      <tr> &nbsp;&nbsp;&nbsp;&nbsp;
                        <td><label>
                          <input name="description" class="form-control" type="text"  id="description" size="24" placeholder="Description" />
                        </label></td>
                      </tr>
                      <br/>

                          <th><label align="left">&nbsp;<p>Category</p>
                            <select name="category" class="form-control input-sm" type="text" id="category">
                              <option value="Breads">Breads</option>
                              <option value="Pastries">Pastries</option>
                              <option value="Cakes">Cakes</option>
                              <option value="Cakes2">Other Cakes</option>
                            </select>
                          </label></th>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                          <th align="right"></th>
                          <th><label>&nbsp;<p>Stocks</p>
                            <select name="stock" class="form-control input-sm" type="text" id="stock">
                              <option value="1">1</option>
                              <option value="2">2</option>
                              <option value="3">3</option>
                              <option value="4">4</option>
                              <option value="5">5</option>
                              <option value="6">6</option>
                              <option value="7">7</option>
                              <option value="8">8</option>
                              <option value="9">9</option>
                              <option value="10">10</option>
                              <option value="11">11</option>
                              <option value="12">12</option>
                              <option value="13">13</option>
                              <option value="14">14</option>
                              <option value="15">15</option>
                              <option value="16">16</option>
                              <option value="17">17</option>
                              <option value="18">18</option>
                              <option value="19">19</option>
                              <option value="20">20</option>
                              <option value="21">21</option>
                              <option value="22">22</option>
                              <option value="23">23</option>
                              <option value="24">24</option>
                              <option value="25">25</option>
                              <option value="26">26</option>
                              <option value="27">27</option>
                              <option value="28">28</option>
                              <option value="29">29</option>
                              <option value="30">30</option>
                              <option value="31">31</option>
                              <option value="32">32</option>
                              <option value="33">33</option>
                              <option value="34">34</option>
                              <option value="35">35</option>
                              <option value="36">36</option>
                              <option value="37">37</option>
                              <option value="38">38</option>
                              <option value="39">39</option>
                              <option value="40">40</option>
                              <option value="41">41</option>
                              <option value="42">42</option>
                              <option value="43">43</option>
                              <option value="44">44</option>
                              <option value="45">45</option>
                              <option value="46">46</option>
                              <option value="47">47</option>
                              <option value="48">48</option>
                              <option value="49">49</option>
                              <option value="50">50</option>
                              <option value="51">51</option>
                              <option value="52">52</option>
                              <option value="53">53</option>
                              <option value="54">54</option>
                              <option value="55">55</option>
                              <option value="56">56</option>
                              <option value="57">57</option>
                              <option value="58">58</option>
                              <option value="59">59</option>
                              <option value="60">60</option>
                              <option value="61">61</option>
                              <option value="62">62</option>
                              <option value="63">63</option>
                              <option value="64">64</option>
                              <option value="65">65</option>
                              <option value="66">66</option>
                              <option value="67">67</option>
                              <option value="68">68</option>
                              <option value="69">69</option>
                              <option value="70">70</option>
                              <option value="71">71</option>
                              <option value="72">72</option>
                              <option value="73">73</option>
                              <option value="74">74</option>
                              <option value="75">75</option>
                              <option value="76">76</option>
                              <option value="77">77</option>
                              <option value="78">78</option>
                              <option value="79">79</option>
                              <option value="80">80</option>
                              <option value="81">81</option>
                              <option value="82">82</option>
                              <option value="83">83</option>
                              <option value="84">84</option>
                              <option value="85">85</option>
                              <option value="86">86</option>
                              <option value="87">87</option>
                              <option value="88">88</option>
                              <option value="89">89</option>
                              <option value="90">90</option>
                              <option value="91">91</option>
                              <option value="92">92</option>
                              <option value="93">93</option>
                              <option value="94">94</option>
                              <option value="95">95</option>
                              <option value="96">96</option>
                              <option value="97">97</option>
                              <option value="98">98</option>
                              <option value="99">99</option>
                              <option value="100">100</option>
                            </select>
                          </label></th>
                        </div>
                        </tr>
                      </br></br>
                      <td align="left">Image</td>
                      <td><label>
                        <input type="file" name="fileField" id="fileField" />
                      </label></td>
                    </tr>
                    <tr>
                    </br></br></br>
                    <td>&nbsp;</td>
                    <td><label>
                      <input type="submit" name="button" class="btn btn-default" id="button" value="Add" />
                    </label></td>
                  </tr>
                </div>
              </form>
            </div>
          </section>

          <footer class="text-center">
                 <div class="footer-above">
                     <div class="container">
                         <div class="row">
                             <div class="footer-col col-md-4">
                                 <h3>Location</h3>
                                 <p>Brgy. Kudanding, Isulan</br>Sultan Kudarat</p>
                             </div>
                             <div class="footer-col col-md-4">
                                 <h3>Around the Web</h3>
                                 <ul class="list-inline">
                                     <li>
                                         <a href="facebook.com" class="btn-social btn-outline"><i class="fa fa-fw fa-facebook"></i></a>
                                     </li>
                                     <li>
                                         <a href="#" class="btn-social btn-outline"><i class="fa fa-fw fa-google-plus"></i></a>
                                     </li>
                                     <li>
                                         <a href="#" class="btn-social btn-outline"><i class="fa fa-fw fa-twitter"></i></a>
                                     </li>
                                     <li>
                                         <a href="#" class="btn-social btn-outline"><i class="fa fa-fw fa-linkedin"></i></a>
                                     </li>
                                     <li>
                                         <a href="#" class="btn-social btn-outline"><i class="fa fa-fw fa-dribbble"></i></a>
                                     </li>
                                 </ul>
                             </div>
                             <div class="footer-col col-md-4">
                                 <h3>About the Programming Language</h3>
                                 <p>KeMitch is appreciating the open source webtool <a href="http://getbootstrap.com">Bootstrap 3</a>.</p>
                             </div>
                         </div>
                     </div>
                 </div>
                 <div class="footer-below">
                     <div class="container">
                         <div class="row">
                             <div class="col-lg-12">
                                 Copyright &copy; KeMitch 2016
                             </div>
                         </div>
                     </div>
                 </div>
             </footer>

<div class="scroll-top page-scroll visible-xs visble-sm">
    <a class="btn btn-primary" href="#page-top">
        <i class="fa fa-chevron-up"></i>
    </a>
</div>

<!-- jQuery Version 1.11.0 -->
<script src="../../../js/jquery-1.11.0.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="../../../js/bootstrap.min.js"></script>

<!-- Plugin JavaScript -->
<script src="../../../js/jquery.easing.min.js"></script>
<script src="../../../js/classie.js"></script>
<script src="../../../js/cbpAnimatedHeader.js"></script>

<!-- Contact Form JavaScript -->
<script src="../../../js/jqBootstrapValidation.js"></script>

<!-- Custom Theme JavaScript -->
<script src="../../../js/freelancer.js"></script>

</body>
</html>
