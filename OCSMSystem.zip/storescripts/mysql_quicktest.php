<?php
 
require "connect_to_mysql.php";  

echo "<h1>Success in database connection! Happy Coding!</h1>";   

?>