<!DOCTYPE html>
<html lang="en">
<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Gretz Paul Food Corporation</title>
  <link href="css/js-image-slider.css" rel="stylesheet" type="text/css" />
  <script src="js/js-image-slider.js" type="text/javascript"></script>
  <!-- Bootstrap Core CSS - Uses Bootswatch Flatly Theme: http://bootswatch.com/flatly/ -->
  <link href="css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom CSS -->
  <link href="css/freelancer.css" rel="stylesheet">
  <link href="css/mediaquery.css" rel="stylesheet">

  <!-- Custom Fonts -->
  <link href="js/jquery.easing.min.js" rel="stylesheet" type="text/css">
  <link href="js/jsfontaccurate.js" rel="stylesheet" type="text/css">
  <link href="font-awesome-4.1.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <link href="css/font.css" rel="stylesheet" type="text/css">
  <link href="css/fontfamily.css" rel="stylesheet" type="text/css">
  <link href="themes/1/js-image-slider.css" rel="stylesheet" type="text/css" />
  <script src="themes/1/js-image-slider.js" type="text/javascript"></script>
  <link href="generic.css" rel="stylesheet" type="text/css" />

</head>
<body>



  <!-- jQuery Version 1.11.0 -->
  <script src="js/jquery-1.11.0.js"></script>

  <!-- Bootstrap Core JavaScript -->
  <script src="js/bootstrap.min.js"></script>

  <!-- Plugin JavaScript -->
  <script src="js/jquery.easing.min.js"></script>
  <script src="js/classie.js"></script>
  <script src="js/cbpAnimatedHeader.js"></script>

  <!-- Contact Form JavaScript -->
  <script src="js/jqBootstrapValidation.js"></script>

  <!-- Custom Theme JavaScript -->
  <script src="js/freelancer.js"></script>

</body>
</html>
